export function JwtSecrets() {
  return (
    <div>
      <h1 className="text-2xl font-bold text-slate-900">JWT Secrets</h1>
      <p className="mt-2 text-slate-600">
        Gerenciamento da chave secreta usada na comunicação com as APIs.
      </p>
    </div>
  );
}