export interface JwtSecret {
  id: string;
  name: string;
  secret: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface CreateJwtSecretRequest {
  name: string;
  secret: string;
}

export interface UpdateJwtSecretRequest {
  name?: string;
  secret?: string;
  isActive?: boolean;
}